#********************************************************************************
#** Nick Coombe, Jakob Fields, Christopher Soresi, and Paolo Albano ***
#** ISU ***
#** ***
#** This file contains the main story ***
#** All engine "commands" are listed below ***
#** ***
#********************************************************************************


# e.load_actor("file_name")
#   - file_name is a .png in the data/images/actors folder
#   - with the default_name/mad_name/happy_name format

# e.load_audio("sound_file", volume)
#   - sound_file is a .ogg under data/audio folder
#   - volume must be between 0 <-> 1

# e.load_background("file_name")
#   - file_name is a .png in the data/images/backgrounds
#   - folder

# e._current_background = loaded_background
#   - change the active drawing background

# e.text_dialogbox("name", "text")
#   - Will draw a text dialog box
#   - If name is left blank, the name box will not be drawn
#   - Text will auto format, do not add \n's in unless needed

# e.draw_ask_dialogbox(["option1", "option2", etc.])
#   - Will draw a "ask" dialog box
#   - Takes an array of strings and returns the string which was chosen

# e.fade_in_card("title", "subtitle")
#   - Will draw a fade-in box

# Between fade-in and fade-out command
# you must change the background or other stuff
# to get "seamless" transitions

# e.fade_out_card("title", "subtitle")
#   - Will draw a fade-out box

# e.add_actor(actor["mood"])
#   - Add actor to active actors
#   - Current moods are default/mad/happy
#   - Actor is imported from e.load_actor command

# e.clear_actors()
#   - Clear all active actors from the screen


import pygame
import Engine as e
import sys

# Load game assets ------------------------------------------------#

boy = e.load_actor("boy")
girl = e.load_actor("girl")
arn = e.load_actor("arn")
trix = e.load_actor("trix")
ree = e.load_actor("ree")
#e._active_actors.append(boy["default"])
#e._active_actors.append(girl["mad"])

music = e.load_audio("music", 0.05)

background = e.load_background("hallway")
menu = e.load_background("Bed")
classroom = e.load_background("classroom")
field = e.load_background("field")
music.play(-1)

#sterotype

bad = 0
good = 0


#POSSIBLE LOVES (Star next means healthy)
#Duncan*
#Issac
#Linnesay*
#Britnay


# Main game loop --------------------------------------------------#

#Jakob Wrote story and all choices
#nick Made engine
#Chris did sounds and images
#Paolo did the editing and some minor  bug fixes


while True:


    e._current_background = menu
    e.text_dialogbox("Narrator", "Welcome To Highschool Simulator where you will be able to make choices and decide your fate")
    e.text_dialogbox("Narrator", "To play you click the arrow at the bottom right and when a choice comes up you click on the one you decide on")
    e.text_dialogbox("Narrator", "You just moved to the beautiful town of Famaria but its the middle of the year and a new school means new possibilities!")
    input_q = e.draw_ask_dialogbox(["Ready to start", "Tutorial again"])
    
    if input_q == "Ready to start":

        # To do a fade, first you call fade in,
        e.fade_in_card("Dawn of The First Day", "-72 Hours Remain-")

        # Then change the background
        e._current_background = background

        # Then fade out
        e.fade_out_card("Dawn of The First Day", "-72 Hours Remain-")

        e._current_background = background
        
        

            
        e.text_dialogbox("Narrator", "You Finally make it to school but you dont know where your class is. there are two students up ahead")
        e.add_actor(boy["default"])
        e.add_actor(girl["default"])
        input_t = e.draw_ask_dialogbox(["Ask Boy for help", "Ask Girl for help"])
            
            
            


        e.clear_actors()

        if input_t == "Ask Boy for help":
            e.add_actor(boy["mad"])
            e.text_dialogbox("???", "Hey, what makes you think you can barge in on my turf!?")
            e.clear_actors()
            e.add_actor(boy["default"])
            e.text_dialogbox("???", "Im just fooling around")
            e.text_dialogbox("Duncan", "Hi, i'm Duncan. No need to run away scared. Welcome to the school. What class do you have?")
            e.text_dialogbox("", "I have no idea, uh looks like uh...")
            e.text_dialogbox("Duncan", "You are with Mr. Reeman on the third floor... room 368")
            e.text_dialogbox("Duncan", "Want me to walk you there?")
            input_u = e.draw_ask_dialogbox(["Yes", "No"])

            if  input_u == "Yes":
                e.text_dialogbox("Duncan", "Ok sweet lets go")
                e.text_dialogbox("Duncan", "I know your new but That girl over there is Britney She sucks")
                e.text_dialogbox("Duncan", "Ok heres your class see you later Ill be sitting in the Caf at lunch")
                e.clear_actors()
                good += 1
            elif input_u == "No":
                e.text_dialogbox("Duncan", "Ok See ya later then, its up ahead on your left")
                e.clear_actors()
                good += 1
                    
        elif input_t == "Ask Girl for help":
            e.add_actor(girl["mad"])
            e.text_dialogbox("", "Hello?")
            e.clear_actors()
            e.add_actor(girl["default"])
            e.text_dialogbox("???", "Are you talking to me?")
            e.text_dialogbox("???", "You have no idea who I am")
            e.text_dialogbox("", "um, Im new here and...")
            e.text_dialogbox("???", "You stay away from me and my people you cant handle hanging out with me.")
            e.add_actor(boy["default"])
            e.text_dialogbox("???", "um,, Hey leave her alone. Come with me")
            e.text_dialogbox("Britney", "Im Britney remember that , Now scram unless you think you can be one of us.")    
            input_y = e.draw_ask_dialogbox(["Stay with Britney", "Go with boy"])
            e.clear_actors()
                
            if input_y == "Go with boy":
                e.add_actor(boy["default"])
                e.text_dialogbox("", "Uh thanks for helping me that girl is a uh...")
                e.text_dialogbox("Duncan", "A Meanie. Hi, i'm Duncan. No need to run away scared. Welcome to the school. What class do you have?")
                e.text_dialogbox("", "I have no idea, uh looks like uh...")
                e.text_dialogbox("Duncan", "You are with Mr. Reeman on the third floor... room 368")
                e.text_dialogbox("Duncan", "Want me to walk you there?")
                input_u = e.draw_ask_dialogbox(["Yes", "No"])

                if  input_u == "Yes":
                        e.text_dialogbox("Duncan", "Ok sweet lets go")
                        e.text_dialogbox("Duncan", "I know your new but That girl over there is Britney She sucks")
                        e.text_dialogbox("Duncan", "Ok heres your class see you later Ill be sitting in the Caf at lunch")
                        e.clear_actors()
                        good += 2
                elif input_u == "No":
                        e.text_dialogbox("Duncan", "Ok See ya later then its up ahead on your left")
                        e.clear_actors()
                        good += 1
                    
            elif input_y == "Stay with Britney":
                e.add_actor(boy["default"])
                e.add_actor(girl["default"])
                e.text_dialogbox("", "Im fine I'll be staying with Britney")
                e.text_dialogbox("Duncan","Oh Ok bye Im Duncan by the way")
                e.clear_actors()
                e.add_actor(girl["happy"])
                e.text_dialogbox("Britney","Oh you have Reeman first period he is awful lets skip!")
                input_i = e.draw_ask_dialogbox(["Skip class and hangout with the cool kids", "Look for class"])
                bad += 1
                e.clear_actors()
                    
                if input_i == "Look for class":
                    e.add_actor(girl["default"])
                    e.text_dialogbox("", "Ug I cant do that bye")
                    e.text_dialogbox("Britney", "Never talk to me again")
                    e.text_dialogbox("Narrator", "You find yourself lost and get to class 20 minutes late")
                    
                    e.clear_actors()
                        
                elif input_i == "Skip class and hangout with the cool kids":
                    bad += 1
                    e.add_actor(girl["happy"])
                    e.text_dialogbox("", "Ok lets do this")
                    e.text_dialogbox("Britney", "Maybe you are cool lets go!")

# CHUNK 1 FIRST SPLIT 


        #*****************GO TO CLASS PATH******************** 

        if good > 0:
            e.clear_actors()
            e._current_background = classroom                            
            e.text_dialogbox("Narrator", " You enter Mr.Reeman class and you suddenly feel Queasy. The teacher looks like a sweaty hog as he snorts for you to sit. ")
            
            e.text_dialogbox("Narrator","There are two spots open one in the back with a red headed boy and one in the front with a black haired girl")
            e.add_actor(arn["default"])
            e.add_actor(trix["default"])
            input_i = e.draw_ask_dialogbox(["Sit with redhead", "Sit with black haired"])
            e.clear_actors()
            
            if input_i == "Sit with redhead":
                e.add_actor(arn["default"])
                e.text_dialogbox("Narrator","You sit next to the redhead he appears to be a nerd he smells slightly of B.O.")
                e.text_dialogbox("Narrator","Its is managable")
                e.text_dialogbox("Issac","Hey my name is Issac but my colleagues call me nerdy 4 eyes")
                e.text_dialogbox("Nerdy 4 eyes","But I'm fine with it")
                input_i = e.draw_ask_dialogbox(["muster through", "Beauty sleep"])

                if input_i == "muster through":
                    e.text_dialogbox("Narrator","you muster through class even though it being difficult")
                    e.text_dialogbox("Nerdy","*Blushing* Woah you were paying attention to that boring lesson all I could pay attention was your plump brain")
                    e.text_dialogbox("Narrator","The bell rings and you go to period 2")
                    e.clear_actors()
                    
                elif input_i == "Beauty sleep":
                    e.text_dialogbox("Narrator","you fall asleep and when you wake up your being stared at")
                    e.text_dialogbox("Nerdy","*woah you are a dork")
                    e.text_dialogbox("Narrator","The bell rings and you go to period 2 after being yelled at by Mr V")
                    e.clear_actors()
                
            

            elif input_i == "Sit with black haired":
                e.add_actor(trix["default"])
                e.text_dialogbox("Narrator","you sit next to the girl")
                e.text_dialogbox("","Hello?")
                e.text_dialogbox("Narrator","she slowly turns her head at you. ")
                e.text_dialogbox("Linnesay","Im Linnesay What do you like need uh....")
                input_i = e.draw_ask_dialogbox(["Chat with her", "Do your work"])
                if input_i == "Chat with her":
                    e.text_dialogbox("Narrator","you look at her and try to start a conversation")
                    e.text_dialogbox("Linnesay","Uh...hello...I'm linnesay with two n's")
                    e.text_dialogbox("","Oh thats cool")
                    e.add_actor(ree["mad"])
                    e.text_dialogbox("Mr Reeman","New Kid be quiet I am doing attendance!")
                    e.clear_actors()
                    
                elif input_i == "Do your work":
                    e.text_dialogbox("Narrator","you fall asleep and when you wake up your being stared at")
                    e.text_dialogbox("Nerdy","*woah you are a dork")
                    e.text_dialogbox("Narrator","The bell rings and you go to period 2 after being yelled at by Mr V")
                    e.clear_actors()
                

        #******************SKIP CLASS PATH*************************    
        elif bad > 0:
            e._current_background = field    
            e.text_dialogbox("Narrator", "You ditch school and talk about usueless stuff with Britney and her friends")
            e.add_actor(girl["default"])
            e.add_actor(girl["mad"])
            e.add_actor(girl["happy"])
            e.text_dialogbox("Narrator", "The bell rings but as that happens a teacher apporaches")
            e.text_dialogbox("Britney", "Can you distract the teach and take the blame for us?")
            input_i = e.draw_ask_dialogbox(["Take blame", "Run away","cry and beg for forgiveness"])

            if input_i == "Take blame":
                e.clear_actors()
                e.text_dialogbox("Narrator", "You save Britney by lying and saying only you skipped you get sent home from school")
                e.text_dialogbox("Narrator", "Day 1 Complete")
                e.clear_actors()
                # To do a fade, first you call fade in,
                e.fade_in_card("Dawn of The Second Day", "-48 Hours Remain-")

        # Then change the background
                e._current_background = background

        # Then fade out
                e.fade_out_card("Dawn of The Second Day", "-48 Hours Remain-")

                e._current_background = background
                

                
            elif input_i == "Run away":
                e.clear_actors()
                e.add_actor(girl["default"])
                e.add_actor(girl["mad"])
                e.text_dialogbox("Narrator", "You run away and a random girl takes the fall Britney gives you a look")
                e.clear_actors()

            elif input_i == "cry and beg for forgiveness":
               
                e.clear_actors()
                e.text_dialogbox("Narrator", "You cry and beg for forgiveness . Britney and her friends get sent home and you get sent to your second class")
                e.clear_actors()


#****Restarting Tutorial/ No paths after this part****
                
    elif input_q == "Tutorial again":
        e.text_dialogbox("", "Ok Here is how you play")
